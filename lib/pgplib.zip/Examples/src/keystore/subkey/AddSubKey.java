/*
 * Copyright 2016 DidiSoft Inc 
 * All Rights Reserved.
 */

package keystore.subkey;

import com.didisoft.pgp.EcCurve;
import com.didisoft.pgp.KeyPairInformation;
import com.didisoft.pgp.KeyStore;

public class AddSubKey {
	public static void main(String[] args) throws Exception{
		// create an instance of an in-memory the KeyStore
		KeyStore keyStore = new KeyStore();
		
		KeyPairInformation key = keyStore.generateRsaKeyPair(512, "my userId", "my key password", 365);
		
		// appends a new sub key
		boolean isEncryptionSubKey = true;
		long newSubKeyId = keyStore.addSubKey(key.getKeyID(), "my key password", isEncryptionSubKey, EcCurve.Enum.NIST_P_521);
		
		// removes the sub key
		keyStore.deleteSubKey(newSubKeyId);
	}
}
