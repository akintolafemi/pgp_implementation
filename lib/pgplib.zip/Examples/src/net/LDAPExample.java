package net;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;

import com.didisoft.pgp.net.LDAPClient;

/**
 * This example demonstrates communication with an LDAP OpenPGP key server
 *
 * Copyright (c) DidiSoft 2014
 */
public class LDAPExample {

	public static void main(String[] args) throws Exception
	{
		LDAPClient ldap = new LDAPClient("127.0.0.1");//"keyserver.pgp.com");//
		
		FileInputStream fIn = new FileInputStream("c:\\Test\\new3\\DidiSoftSupport.asc");
		ByteArrayOutputStream bOut = new ByteArrayOutputStream();
		int i = -1;
		while ((i = fIn.read()) != -1) {
		    bOut.write(i);
		}
		
		boolean submitted = ldap.submitKey(bOut.toByteArray());
		
		byte[] keyBytes = ldap.getKeyByKeyIdHex("93827462"); 
		
		System.out.println(keyBytes.length);
		System.out.println(new String(keyBytes, "ASCII"));
	}
}
